
		public class AccessModifier {

			public int x = 10;
			protected int y = 20;
			int z = 30;
			private int zz = 40;

			public void publicMethod() { 
				System.out.println("This is a public method.");
			}

			protected void protectedMethod() {
				System.out.println("This is a protected method.");
			}

			void defaultMethod() {

			System.out.println("This is a default method.");

			}

			private void privateMethod() {
				System.out.println("This is a private method.");

			}

			public static void main(String[] args) {
				AccessModifier obj = new AccessModifier();

			System.out.println("Public variable: " + obj.x);
				obj.publicMethod();

			System.out.println("Protected variable:" + obj.y);
				obj.protectedMethod();

			System.out.println("Default variable: " + obj.z);
				obj.defaultMethod();
			
		
	}
}
	


